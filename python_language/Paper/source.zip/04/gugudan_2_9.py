print('-' * 50)

for a in range(2, 10) :         # 2단 ~ 9단
    for b in range(1, 10) :
        c = a * b
        print('%d x %d = %d' % (a, b, c))
           
    print('-' * 50)

    

