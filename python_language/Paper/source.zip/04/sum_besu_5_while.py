sum = 0
i = 200

while i <= 500 :
    if i % 5 == 0 :
        sum = sum + i

    i = i + 1
    
print('200 ~ 500까지의 정수 중 5의 배수의 합계 : %d' % (sum))
    

