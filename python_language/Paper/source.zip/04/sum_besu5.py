
sum = 0

for i in range(100, 301, 5) :
    sum = sum + i
    
print('100 ~ 300의 정수 중에서 5의 배수의 합계 : %d' % sum)

