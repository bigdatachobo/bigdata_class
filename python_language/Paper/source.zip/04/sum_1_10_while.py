sum = 0
i = 1

while i <= 10 :
    sum = sum + i
    print('i의 값 : %2d => 합계 : %d' % (i, sum))
    i = i + 1

