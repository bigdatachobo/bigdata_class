a = 2          # 2단

for b in range(1, 10) :
    c = a * b
    print('%d x %d = %d' % (a, b, c))

