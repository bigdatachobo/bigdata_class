for i in range(10) :
    print(i, end =' ')
print()

for i in range(1, 11) :
    print(i, end =' ')
print('\n')

for i in range(1, 10, 2) :
    print(i, end =' ')
print()

for i in range(20, 0, -2) :
    print(i, end =' ')
