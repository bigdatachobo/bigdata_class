sum = 0

for i in range(1, 11) :
    sum = sum + i    
    print('i의 값 : %2d => 합계 : %d' % (i, sum))

