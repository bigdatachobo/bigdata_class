x = int(input('정수를 입력하세요: '))

if x > 0 :
    print('양수이다!')
else :
    print('음수 또는 0이다!')

    
