a = int(input('숫자를 입력해 주세요 : '))

if a % 2 == 0 :
    print('입력된 수 : %s => 짝수' % a)    
else :
    print('입력된 수 : %s => 홀수' % a)
