
year = input('년 : ') 
month = input('월 : ') 
day = input('일 : ') 

print(year, month, day, sep = '/') 
