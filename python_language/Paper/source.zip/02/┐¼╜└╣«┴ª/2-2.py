name = input('당신의 이름은? ') 
birth = int(input('당신의 태어난 해는? ')) 

age = 2018 - birth; 
print(name + '님의 나이는 ' + str(age) + '세 입니다!') 
