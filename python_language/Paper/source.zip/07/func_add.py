def output(n) :
    for i in range(n) :
        print(i)
    
output(10)
output(20)





