def say_hello(name) :
    print('%s님 안녕하세요!' % name)

say_hello('홍지수')
say_hello('안지영')
say_hello('황예린')


