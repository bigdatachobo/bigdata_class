def even_odd(n) :
    if n % 2 == 0 :
        print('%d -> 짝수' % n)
    else :
        print('%d -> 홀수' % n)
    
even_odd(15)
even_odd(26)
