phones = {'갤럭시 S5': 2014, '갤럭시 S7': 2016, '갤럭시 노트8': 2017,  '갤럭시 S9': 2018}
print(phones)

for key in phones :
    print('%s => %s' % (key, phones[key]))

print(len(phones))

