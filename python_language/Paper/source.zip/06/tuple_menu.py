menu = ('짜장면', '우동', '짬뽕', '볶음밥')

print(menu)
print(menu[0])
print(menu[2])
print(menu[0:3])

menu[1] = '사천탕면'



