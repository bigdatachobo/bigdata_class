tup1 = (10,20,30)
tup2 = (40,50,60)
 
tup3 = tup1 + tup2
  
print(tup3)
print(len(tup3))




