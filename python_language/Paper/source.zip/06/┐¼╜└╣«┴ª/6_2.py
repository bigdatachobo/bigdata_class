admin = ('rubato', '12345', 'rubato@naver.com')

print('- 관리자 정보')
print('아이디 : ' + admin[0])
print('비밀번호 : ' + admin[1])
print('이메일 : ' + admin[2])



