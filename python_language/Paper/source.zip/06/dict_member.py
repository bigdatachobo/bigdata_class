members = {'name': '황예린', 'age': 22, 'email': 'yerin@codingschool.info'}

print(members)
print(members['name'])
print(members['age'])

print('길이 : %d' % len(members))

