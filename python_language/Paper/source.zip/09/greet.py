def hello(name) : 
    print('%s님 안녕하세요~~~' % name)

def niceMeet(name) : 
    print('%s님 만나서 반갑습니다~~~' % name)
