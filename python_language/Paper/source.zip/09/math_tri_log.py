import math

# 삼각함수
print('sin(pi/4) : %.2f' % math.sin(math.pi/4))
print('cos(pi) : %.2f' % math.cos(math.pi))
print('tan(pi/6) : %.2f' % math.tan(math.pi/6))

# 승수, 제곱근, 로그 구하기
print('5의 3승 : %d' % math.pow(5,3))
print('144의 제곱근 : %d' % math.sqrt(144))
print('log10(1000) : %.2f' % math.log10(1000))





