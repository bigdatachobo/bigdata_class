from greet import hello, niceMeet

hello('홍채리')
niceMeet('장수연')







