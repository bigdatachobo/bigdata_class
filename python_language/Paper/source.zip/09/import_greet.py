import greet

greet.hello('홍채리')
greet.niceMeet('장수연')







