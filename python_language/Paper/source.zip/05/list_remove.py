member = ['황지웅', 20, '경기도 김포시', 'jiwoang@codingschool.info', '123-1234-5678']
print(member)

member.remove(20)
print(member)




