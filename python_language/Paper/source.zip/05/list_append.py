flower = ['무궁화', '장미', '개나리']
print(flower)

flower.append('벚꽃')
print(flower)

