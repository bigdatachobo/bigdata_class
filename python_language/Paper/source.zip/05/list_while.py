animals = ['사자', '호랑이', '사슴', '곰']

i = 0
while i < len(animals) :
    print(animals[i])

    i = i + 1
    
