strings = [['잠자리', '풍뎅이', '여치'], ['짜장면', '파스타', '피자', '국수']]

for i in range(len(strings)) :
    for j in range(len(strings[i])) :
        print(strings[i][j])

    print()





        
       
