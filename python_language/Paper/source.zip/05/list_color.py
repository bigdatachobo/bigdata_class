color = ['red', 'green', 'blue', 'black', 'white']

print(color[0])
print(color[4])
print(color[1:4])
