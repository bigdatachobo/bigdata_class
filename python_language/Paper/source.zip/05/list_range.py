num = list(range(1,21, 2))

print(num)
print(num[3:7])
