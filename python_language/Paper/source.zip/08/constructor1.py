class Person :
    def __init__(self, name) :
        self.name = name
        print('%s님 반갑습니다~~~' % name)

person1 = Person('황예린')


