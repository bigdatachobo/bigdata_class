class Animal :
    name = '고양이'
    def sound(self) :
        print('냐아옹~~~')

cat = Animal()

print(cat.name)
cat.sound()








