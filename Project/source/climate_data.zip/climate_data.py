# -*- coding: utf-8 -*-
"""
Created on Mon Feb 24 15:24:32 2020

@author: sundooedu
"""
#%%
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import glob
import os

def df_flat(data):
    df = pd.read_excel(data)
    year=str(df.iloc[0,0])[0:4]
    
    df = df.drop(['조사지역'], axis=1)
    date_series = pd.Series(df['거래일자'])
    date_f =pd.to_datetime(date_series, format='%Y%m%d', errors='ignore')
    df['거래일자'] = date_f
    df['month_year'] = pd.to_datetime(df['거래일자']).dt.to_period('M')
    df.drop(['거래일자'], axis=1, inplace=True)
    
    df_group = df.groupby(['지역(시)','month_year']).mean()
    df_group.reset_index(inplace=True)
    df_group2 = df_group.groupby(['month_year']).mean()
    df_group2.reset_index(inplace=True)
    
    df_T = df_group2.T # Transpose --> 행/열을 바꿔준다.
    df_T.columns = df_T.loc['month_year',:]
    df_T.drop('month_year',axis=0,inplace=True)
    df_T_res = df_T.reset_index()
    df_T_drop = df_T_res.drop(['index'], axis=1)
    
    col_name = df_T.index.values
    num = [ n for n in range(1,13)]
    
    col_list=[]
    for i in range(len(col_name)):
        temp = col_name[i]
        for j in range(12):
            col_list.append(temp+' '+str(j+1)+'월')
            
    df_flat = pd.DataFrame(df_T_drop.values.flatten().reshape(1,-1),
                           columns=col_list,
                           index=[year])     
    return df_flat 

if __name__ == "__main__":
    os.chdir('C:/Users/sundooedu/Downloads/BIGDATA BACKUP/Python/Project/source')
    files = glob.glob('../data/Raw_forecast_*')
    
    df=pd.DataFrame()
    for data in files:
        df=pd.concat([df,df_flat(data)], axis=0)
    
    df.reset_index(inplace=True)
    df.rename(columns={'index':'year'}, inplace=True)    
    df.to_excel('../data/climate_in_a_row.xls',index=False)    
